﻿using System;

namespace Question_59
{
    class Program
    {
        static void Main(string[] args)
        {
            //Part a
            /*
            int n=22/8;
            Console.WriteLine(n);
            */
            //Part b
            /*
            int n=99/8+21/11*7;
            Console.WriteLine(n);
            */
            //part c
            /*
            double a=4, b=3,p=8, q=2;
            double n=q/a-p/b;
            Console.WriteLine(n); 
            */
            //part d
            /*
            int a=6, b=3, p=8, q=2;
            double n=p/a+q/b;
            Console.WriteLine(n);
            */
            //part e
            /*
            int a=(int) 3.3, b=(int)2.7,p=(int)8.7,q=(int)5.4;
            double n=p/b+q/a;
            Console.WriteLine(n);
            */
            //Part f
            /*
            int n=11+7/4+98%6*3;
            Console.WriteLine(n);
            */
            //part g
            /*
            int n=11/31%8*5-12;
            Console.WriteLine(n);
            */
            //Part h
            /*
            double p=8;
            int q=5;
            int n= (int)(q*p+3.0*p*p-(q%3)*p*p*p);
            Console.WriteLine(n);
            */
            //Part i
            /*
            double p=5;
            int q=9;
            int n=(int)((q%2)*p+6.0*p*(q%3)+(q%4)*p*p*p);
            Console.WriteLine(n);
            */
        }
    }
}
