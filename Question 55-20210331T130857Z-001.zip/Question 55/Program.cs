﻿using System;

namespace Question_55
{
    class Program
    {
        static void Main(string[] args)
        {
            //part a
            /*
            int a=3,b=4;
            a=a+1;
            a*=b++;
            Console.WriteLine(a);
            */
            //Part b
            /*
            int a=3,b=4;
            a=a+1;
            a*=++b;
            Console.WriteLine(a);
            */
        }
    }
}
