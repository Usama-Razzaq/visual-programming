﻿using System;

namespace question_52
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Question 52 part a
        Console.WriteLine(1+8/2+((1*4)+(5*4))/4);*/ 
            /* part b
            Console.WriteLine((1+1+1+1)/2+(1+1+1)/3);*/
            /* part c
            Console.WritleLine(5*5+5/5+6);*/
            /* part d
            Console.WriteLine(((3+4)+(4*7))/5);*/
            /* part e
            Console.WriteLine((3*6*7*2)+12/2);*/
            /* part f
            Console.WriteLine(5-3*4%(6-1));*/
            /* part g
            Console.WriteLine((8*4*2+6)/2+4);*/
        }
    }
}
