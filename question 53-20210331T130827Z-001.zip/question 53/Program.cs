﻿using System;

namespace question_53
{
    class Program
    {
        static void Main(string[] args)
        {
            //Part a
            /*
            int x=20, y=35;
            x=y++ + x++;
            y=++y + ++x;
            Console.Write(x);
            Console.Write(y);
            */
            //Part b
            /*
            int x=10, y=15, a,b;
            a=x++;
            b=++y;
            Console.WriteLine(x);
            Console.WriteLine(y);
            */
            //part c
            /*
            int a=10,b;
            b=a++;
            Console.WriteLine(value: a);
            */
            //Part d
            /*
            float x=3.8F;
            Console.WriteLine((int)x);
            */

        }
    }
}
