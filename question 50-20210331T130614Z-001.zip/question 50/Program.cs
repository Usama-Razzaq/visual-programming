﻿using System.IO;
using System;

namespace question_50
{
    class Program
    {
        static void Main(string[] args)
        {
            //conerting the cpp expressions to c#
            // question_50 part a
        //Console.WriteLine(x*x+4*x-4);
            //part b
        //Console.WriteLine{(x+y)*x);
            //part c
        //Console.WriteLine((x+3*y)/(2*x-y));
            //part d
        // Console.WriteLine(1/(x*x+x+3));
            //part f
        // Console.WriteLine(2*b*c*c*c);
            //part g
        // Console.WriteLine((3*y)/(5-z));
            //part h
        // Console.WriteLine(area*sqrt(area));
            // part i
        // Console.WriteLine((x+32)/(y-32)-(x-2*y));
            //part j
        // Console.WriteLine((3*int*j*k+pow(k,9))/(7*i*k-5*sqrt(j+k)));
        }
    }
}
